


public class SkinCare {
    public static void main(String[] args) {
        
    }
    
}
