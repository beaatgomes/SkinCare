/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;


public class ProdutoModel {

    private int userId;
    private String userNome;
    private int userIdade;
    private String userEmail;
    private String userTelefone;
    

    public ProdutoModel() {
    }
    
    public ProdutoModel(int id, String uN, int uI, String uE, String uT) {
        userId = id;
        userNome = uN;
        userIdade = uI;
        userEmail = uE;
        userNome = uT;
    }
    
    public int getUserId() {
        return userId;
    }

    
    public void setUserId(int userId) {
        this.userId = userId;
    }

    
    public String getUserNome() {
        return userNome;
    }

   
    public void setUserName(String userNome) {
        this.userNome = userNome;
    }

    
    public int getUserIdade() {
        return userIdade;
    }

    
    public void setUserIdade(int userIdade) {
        this.userIdade = userIdade;
    }
    
    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    
    public String getUserTelefone() {
        return userTelefone;
    }

    public void setUserTelefone(String userTelefone) {
        this.userTelefone = userTelefone;
    }
}

